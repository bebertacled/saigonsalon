
  # Saigon Salon Launch

  This is a code bundle for Saigon Salon Launch. The original project is available at https://www.figma.com/design/LBWJScvQyJ5rL69tzaNu2q/Saigon-Salon-Launch.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  